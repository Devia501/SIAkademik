import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
  Image,
  Dimensions,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { AuthStackParamList } from '../../navigation/AppNavigator'; 

type LandingScreenNavigationProp = NativeStackNavigationProp<
  AuthStackParamList,
  'Landing' // Nama layar saat ini
>;

const { width, height } = Dimensions.get('window');

const LandingScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('../../assets/images/campus-building.jpeg')}
        style={styles.backgroundImage}
        imageStyle={styles.imageStyle}
      >
        <View style={styles.overlay} />
      </ImageBackground>

      <View style={styles.contentContainer}>
        <View style={styles.waveContainer}>
          <View style={styles.wave} />
        </View>

        <View style={styles.logoContainer}>
          <Image
            source={require('../../assets/images/logo-ugn2.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        <Text style={styles.title}>UNIVERSITAS GLOBAL NUSANTARA</Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.loginButton]}
            onPress={() => navigation.push('Login')} 
            activeOpacity={0.8}
          >
            <Text style={styles.loginButtonText}>Login</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.registerButton]}
            onPress={() => navigation.push('Register')}
        activeOpacity={0.8}
          >
            <Text style={styles.registerButtonText}>Register</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#015023',
  },
  backgroundImage: {
    width: width,
    height: height * 0.5,
    position: 'absolute',
    top: 0,
  },
  imageStyle: {
    opacity: 0.9,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.15)',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingHorizontal: 30,
    paddingBottom: 80,
  },
  waveContainer: {
    position: 'absolute',
    top: height * 0.42,
    left: 0,
    right: 0,
    height: 100,
    zIndex: 5,
  },
  wave: {
    position: 'absolute',
    bottom: 0,
    left: -width * 0.1,
    width: width * 1.2,
    height: 110,
    backgroundColor: '#015023',
    borderTopLeftRadius: width * 0.6,
    borderTopRightRadius: width * 0.6,
  },
  logoContainer: {
    width: 100,
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 25,
    zIndex: 10,
    
  },
  logo: {
    width: '140%',
    height: '200%',
    
  },
  title: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 30,
    letterSpacing: 1,
    
  },
  buttonContainer: {
    width: '65%',
    gap: 26,
    height: '16%',
  },
  button: {
    width: '100%',
    paddingVertical: 6,
    borderRadius: 50,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 1.85,
    shadowRadius: 9.84,
    elevation: 5,
  },
  loginButton: {
    backgroundColor: '#DABC4E',
  },
  loginButtonText: {
    color: '#F5EFD3',
    fontSize: 16,
    fontWeight: '500',
  },
  registerButton: {
    backgroundColor: '#F5F5DC',
  },
  registerButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '500',
  },
});

export default LandingScreen;